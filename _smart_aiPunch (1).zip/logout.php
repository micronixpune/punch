<?php
session_start();
session_unset();
setcookie('user_token', '', time() - 3600, "/"); // expire token
session_destroy();
header("Location: tenant_enter_email.php");
exit();
?>
