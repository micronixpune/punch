<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET['email'])) {
    $email = $_GET['email'];
} elseif ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['email'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (strlen($password) < 6) {
        echo "Password must be at least 6 characters.";
        exit();
    }
    $confirm = $_POST['confirm_password'];
if ($password !== $confirm) {
    echo "❌ Passwords do not match.<br><a href='set_password.php?email=" . urlencode($email) . "'>Try again</a>";
    exit();
}


    $hashed = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $pdo->prepare("UPDATE tenant_users SET password_hash = ? WHERE email = ?");
        $stmt->execute([$hashed, $email]);
        echo "✅ Password set successfully.<br><a href='tenant_login.php'>Login now</a>";
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
    exit();
} else {
    echo "Invalid access.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Set Your Password</title>
</head>
<body>
  <h2>Set Password for <?= htmlspecialchars($email) ?></h2>
  <form action="set_password.php" method="POST">
  <input type="hidden" name="email" value="<?= htmlspecialchars($email) ?>">
  
  <label>New Password:</label><br>
  <input type="password" name="password" required><br><br>
  
  <label>Confirm Password:</label><br>
  <input type="password" name="confirm_password" required><br><br>
  
  <button type="submit">Set Password</button>
</form>

</body>
</html>
