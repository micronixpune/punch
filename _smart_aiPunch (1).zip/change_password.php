<?php
session_start();
require 'db.php';

if (!isset($_SESSION['tenant_logged_in'])) {
    header("Location: tenant_enter_email.php");
    exit();
}

$user_id = $_SESSION['tenant_user_id'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $current = $_POST['current_password'];
    $new     = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    // Fetch current hash
    $stmt = $pdo->prepare("SELECT password_hash FROM tenant_users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($current, $user['password_hash'])) {
        echo "❌ Current password is incorrect.";
        exit();
    }

    if (strlen($new) < 6) {
        echo "❌ New password must be at least 6 characters.";
        exit();
    }

    if ($new !== $confirm) {
        echo "❌ New passwords do not match.";
        exit();
    }

    // Update hash
    $new_hash = password_hash($new, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE tenant_users SET password_hash = ? WHERE id = ?");
    $stmt->execute([$new_hash, $user_id]);

    echo "✅ Password changed successfully.<br><a href='tenant_dashboard.php'>Return to Dashboard</a>";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head><title>Change Password</title></head>
<body>
  <h2>Change Your Password</h2>
  <form method="POST">
    <label>Current Password:</label><br>
    <input type="password" name="current_password" required><br><br>

    <label>New Password:</label><br>
    <input type="password" name="new_password" required><br><br>

    <label>Confirm New Password:</label><br>
    <input type="password" name="confirm_password" required><br><br>

    <button type="submit">Change Password</button>
  </form>
  <p><a href="tenant_dashboard.php">Cancel</a></p>
</body>
</html>
