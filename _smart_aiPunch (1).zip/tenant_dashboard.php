<?php
session_start();
if (!isset($_SESSION['platform_logged_in']) || $_SESSION['platform_logged_in'] !== true) {
  header("Location: login.php");
  exit;
}

// Optional: greet user by role or ID
$role = $_SESSION['tenant_role'];
?>

<!DOCTYPE html>
<html>
<head>
  <title>Tenant Dashboard – Smart Attendance</title>
</head>
<body>
  <h2>Welcome, Tenant <?= ucfirst($_SESSION['tenant_role']) ?>!</h2>
  <p>You are now logged in to your company’s dashboard.</p>

  <hr>
  <h3>Employee Management</h3>
  <ul>
    <li><a href="add_employee.php">➕ Add Employee</a></li>
    <li><a href="view_employees.php">👀 View Employees</a></li>
  </ul>

  <hr>
  <p><a href="change_password.php">Change Password</a></p>
  <p><a href="logout.php">Logout</a></p>
</body>
</html>

