<?php
session_start();
require 'db.php';

if (!isset($_SESSION['tenant_logged_in'])) {
    header("Location: tenant_enter_email.php");
    exit();
}

$tenant_id = $_SESSION['tenant_id'];

try {
    $stmt = $pdo->prepare("SELECT * FROM employees WHERE tenant_id = ?");
    $stmt->execute([$tenant_id]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Employee List</title>
</head>
<body>
  <h2>Your Employees</h2>

  <?php if ($employees): ?>
    <table border="1" cellpadding="10">
      <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Department</th>
        <th>Employee Code</th>
      </tr>
      <?php foreach ($employees as $emp): ?>
        <tr>
          <td><?= htmlspecialchars($emp['first_name'] . ' ' . $emp['middle_name'] . ' ' . $emp['last_name']) ?>
</td>
          <td><?= htmlspecialchars($emp['email']) ?></td>
          <td><?= htmlspecialchars($emp['department']) ?></td>
          <td><?= htmlspecialchars($emp['employee_code']) ?></td>
        </tr>
      <?php endforeach; ?>
    </table>
  <?php else: ?>
    <p>No employees found yet.</p>
  <?php endif; ?>

  <p><a href="add_employee.php">➕ Add Employee</a> | <a href="tenant_dashboard.php">🏠 Dashboard</a></p>
</body>
</html>
