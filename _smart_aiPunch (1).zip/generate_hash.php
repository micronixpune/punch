<?php
echo password_hash("Micronix@123", PASSWORD_DEFAULT);
