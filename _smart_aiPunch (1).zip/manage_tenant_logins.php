<?php
session_start();
require 'db.php';

if (!isset($_SESSION['platform_logged_in']) || $_SESSION['platform_logged_in'] !== true) {
  header("Location: login.php");
  exit;
}

// Fetch tenant users and join tenant info
$stmt = $pdo->prepare("
  SELECT tu.id, tu.email, tu.role, tu.password_hash, tu.last_login, t.org_name 
  FROM tenant_users tu
  JOIN tenants t ON tu.tenant_id = t.id
  ORDER BY t.org_name, tu.email
");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Stats
$totalUsers = count($users);
$pendingUsers = count(array_filter($users, fn($u) => empty($u['password_hash'])));
$activeUsers = $totalUsers - $pendingUsers;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Tenant Logins</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .stats-card { border-left: 5px solid #007bff; background: #f8f9fa; }
    .status-pill { border-radius: 20px; padding: 4px 12px; font-size: 0.85rem; }
    .dashboard-table th, .dashboard-table td { vertical-align: middle; }
    .search-bar { max-width: 400px; }
  </style>
</head>
<body class="bg-light">

<div class="container my-5">
  <h2 class="mb-4">🧩 Manage Tenant Logins</h2>

  <!-- 📊 Stats Cards -->
  <div class="row mb-4">
    <div class="col-md-4">
      <div class="p-3 stats-card shadow-sm">
        <h5 class="text-primary">👥 Total Users</h5>
        <h3><?= $totalUsers ?></h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-3 stats-card shadow-sm" style="border-left-color: #28a745;">
        <h5 class="text-success">✅ Active Users</h5>
        <h3><?= $activeUsers ?></h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-3 stats-card shadow-sm" style="border-left-color: #ffc107;">
        <h5 class="text-warning">⏳ Pending Setup</h5>
        <h3><?= $pendingUsers ?></h3>
      </div>
    </div>
  </div>

  <!-- 🔍 Search Bar -->
  <input type="text" id="searchInput" class="form-control mb-4 search-bar" placeholder="Search by email or tenant name...">

  <!-- 📋 Tenant Logins Table -->
  <div class="table-responsive">
    <table class="table table-bordered table-hover bg-white dashboard-table" id="loginTable">
      <thead class="table-secondary">
        <tr>
          <th>#</th>
          <th>Tenant</th>
          <th>Email</th>
          <th>Role</th>
          <th>Status</th>
          <th>Last Login</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $index => $user): ?>
          <tr>
            <td><?= $index + 1 ?></td>
            <td><?= htmlspecialchars($user['org_name']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><span class="badge bg-info text-dark"><?= ucfirst($user['role']) ?></span></td>
            <td>
              <?php if (empty($user['password_hash'])): ?>
                <span class="status-pill bg-warning text-dark">Pending Setup</span>
              <?php else: ?>
                <span class="status-pill bg-success text-white">Active</span>
              <?php endif; ?>
            </td>
            <td>
              <?= $user['last_login'] ? date("d M Y, H:i", strtotime($user['last_login'])) : '<span class="text-muted">Never</span>' ?>
            </td>
            <td>
              <?php if (empty($user['password_hash'])): ?>
                <a href="set_password.php?email=<?= urlencode($user['email']) ?>" class="btn btn-sm btn-outline-primary">Send Setup</a>
              <?php else: ?>
                <a href="change_password.php?email=<?= urlencode($user['email']) ?>" class="btn btn-sm btn-outline-warning">Reset</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <a href="dashboard.php" class="btn btn-secondary mt-4">← Back to Dashboard</a>
</div>

<!-- 🔎 Filter Script -->
<script>
  document.getElementById("searchInput").addEventListener("input", function () {
    const filter = this.value.toLowerCase();
    document.querySelectorAll("#loginTable tbody tr").forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";
    });
  });
</script>

<?php include 'footer.php'; ?>
</body>
</html>
