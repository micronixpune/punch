<?php
session_start();
require 'db.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $org_name = $_POST['org_name'];
    $subdomain = $_POST['subdomain'];
    $logo_url = $_POST['logo_url'];
    $admin_email = $_POST['admin_email'];
    $super_email = $_POST['super_email'];

    // Construct the URL
    $full_url = $subdomain . "-smart-AI-punch.com";

    try {
        // Insert into tenants table
        $stmt = $pdo->prepare("INSERT INTO tenants (org_name, subdomain_url, logo_url) VALUES (?, ?, ?)");
        $stmt->execute([$org_name, $full_url, $logo_url]);
        $tenant_id = $pdo->lastInsertId();

        // Create tenant admin
        $stmt = $pdo->prepare("INSERT INTO tenant_users (tenant_id, role, name, email, password_hash) VALUES (?, 'admin', 'Admin', ?, '')");
        $stmt->execute([$tenant_id, $admin_email]);

        // Create super user
        $stmt = $pdo->prepare("INSERT INTO tenant_users (tenant_id, role, name, email, password_hash) VALUES (?, 'super_user', 'Super User', ?, '')");
        $stmt->execute([$tenant_id, $super_email]);

        echo "✅ Tenant created successfully!<br><a href='dashboard.php'>Go back to Dashboard</a>";

    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}
?>
