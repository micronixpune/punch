<?php
$host = "127.0.0.1:3306";
$dbname = "u429825882_smart_aiPunch";      // ← replace with actual DB name
$username = "u429825882_admin";      // ← replace with DB username
$password = "apollO12!";      // ← replace with DB password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
