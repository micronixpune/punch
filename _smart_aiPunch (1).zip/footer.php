<footer class="text-center py-4 mt-5 border-top">
  <div class="container text-muted small">
    <div>Designed & Developed by-</div>
    <div>Micronix Solutions, Pune.</div>
    <div>Contact: +91 9960679505 | Email: info@micronix.co.in</div>
    <div>© 2025 Micronix Solutions · All rights reserved.</div>
  </div>
</footer>
