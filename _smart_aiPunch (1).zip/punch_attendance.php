<?php
session_start();
// Optional: validate session or access token if needed
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>TimePunch - Record Attendance</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/kiosk.css">
 <link rel="stylesheet" href="assets/css/dark-mode.css">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/face-api.js"></script>

  <style>
    body {
      background: #ffffff;
      font-family: 'Segoe UI', sans-serif;
    }
    .logo-badge {
      font-size: 48px;
      color: #007bff;
    }
    #videoFeed, #overlay {
      border-radius: 12px;
      max-width: 100%;
    }
    .camera-container {
      position: relative;
      width: 100%;
      max-width: 350px;
      margin: auto;
    }
    #overlay {
      position: absolute;
      top: 0;
      left: 0;
    }
    .btn-punch {
      font-size: 1.2rem;
      padding: 12px 24px;
    }
  </style>
</head>
<body class="text-center py-5">

  <div class="container">
    <!-- 🔰 Logo or App Icon -->
    <div class="mb-4">
      <div class="logo-badge">📍</div>
      <h4 class="fw-bold">TimePunch</h4>
      <p class="text-muted">Location-based facial attendance</p>
    </div>

    <!-- 📷 Video + Canvas -->
    <div class="camera-container mb-4">
      <video id="videoFeed" autoplay muted playsinline style="width: 100%; border: 2px solid #007bff;"></video>
      <canvas id="overlay"></canvas>
    </div>

    <!-- 🧠 Optional: Manual trigger for kiosk -->
    <p id="status" class="text-muted small">Align your face and blink to mark attendance.</p>

    <!-- 🔘 Optional punch button -->
    <button class="btn btn-success btn-punch d-none" id="manualPunch">Punch In</button>
  </div>

  <script src="js/face-punch.js"></script>
</body>
</html>
<!-- 🌙 Theme Toggle + Links -->
<div class="mt-4 text-muted small">
  <button id="darkToggle" class="btn btn-sm btn-outline-secondary">🌙</button>
  &middot;
  <a href="punch_attendance.php?mode=kiosk">Kiosk Mode</a>
  &middot;
  <a href="login.php">Reports</a>
</div>

<script src="js/dark-mode.js"></script>
