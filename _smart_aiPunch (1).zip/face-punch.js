// 👁️ FacePunch: Biometric Attendance + Geolocation
const video = document.getElementById('videoFeed');
const overlay = document.getElementById('overlay');
const ctx = overlay.getContext('2d');

let faceMatcher;
let faceDetected = null;

// Load face-api.js models
Promise.all([
  faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
  faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
  faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
  faceapi.nets.faceExpressionNet.loadFromUri('/models')
]).then(initCamera);

// 🎥 Start webcam
function initCamera() {
  navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
    video.srcObject = stream;
    video.onloadedmetadata = () => {
      overlay.width = video.videoWidth;
      overlay.height = video.videoHeight;
      detectLoop();
    };
  });
}

// 🧠 Continuous face + blink detection
async function detectLoop() {
  const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions())
    .withFaceLandmarks().withFaceExpressions();

  ctx.clearRect(0, 0, overlay.width, overlay.height);
  faceapi.draw.drawDetections(overlay, detections);

  if (detections.length === 1) {
    const blink = isBlinking(detections[0]);
    if (blink) {
      faceDetected = detections[0];
      handleAttendance();
    }
  }

  requestAnimationFrame(detectLoop);
}

// 👁 Blink check via EAR (simplified)
function isBlinking(detection) {
  const landmarks = detection.landmarks;
  const leftEye = landmarks.getLeftEye();
  const rightEye = landmarks.getRightEye();

  const EAR = (eye) => {
    const [p1, p2, , p4, p5, p6] = eye;
    const v1 = Math.hypot(p2.x - p6.x, p2.y - p6.y);
    const v2 = Math.hypot(p3.x - p5.x, p3.y - p5.y);
    const h = Math.hypot(p1.x - p4.x, p1.y - p4.y);
    return (v1 + v2) / (2.0 * h);
  };

  const leftEAR = EAR(leftEye);
  const rightEAR = EAR(rightEye);
  return (leftEAR + rightEAR) / 2 < 0.2;
}

// 📍 Location + POST
async function handleAttendance() {
  navigator.geolocation.getCurrentPosition(async position => {
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;

    const locationData = await fetch(`https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lng}&key=4f5c9f1ec8fb4e149089bcf084b56439`)
      .then(res => res.json());

    const comp = locationData.results[0].components;
    const payload = {
      lat,
      lng,
      area: comp.suburb || comp.neighbourhood || 'Unknown',
      city: comp.city || comp.county || comp.state || 'Unknown',
      pincode: comp.postcode || '',
      device: navigator.userAgent,
      photo: captureBase64(video)
    };

    const res = await fetch('log_attendance.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    
    

    const txt = await res.text();
    alert(`✅ ${txt}`);
  }, () => {
    alert('⛔ Location permission denied.');
  });
  if (location.search.includes('mode=kiosk')) {
  setTimeout(() => location.reload(), 5000);
}


new Audio('audio/success.wav').play();

new Audio('audio/error.wav').play();

// 📷 Get base64 photo
function captureBase64(video) {
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d').drawImage(video, 0, 0);
  return canvas.toDataURL('image/jpeg');
}
