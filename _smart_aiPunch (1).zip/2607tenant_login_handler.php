<?php
session_start();
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        $stmt = $pdo->prepare("SELECT * FROM tenant_users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Check if a password hash exists
            if (empty($user['password_hash'])) {
                // Redirect user to set their password first
                header("Location: set_password.php?email=" . urlencode($email));
                exit();
            }

            // Verify entered password against stored hash
            if (password_verify($password, $user['password_hash'])) {
                $_SESSION['tenant_logged_in'] = true;
                $_SESSION['tenant_user_id'] = $user['id'];
                $_SESSION['tenant_id'] = $user['tenant_id'];
                $_SESSION['tenant_role'] = $user['role'];
                $update = $pdo->prepare("UPDATE tenant_users SET last_login = NOW() WHERE id = ?");
$update->execute([$user['id']]);

                header("Location: tenant_dashboard.php");
                exit();
            } else {
                echo "Incorrect password.<br><a href='tenant_login.php'>Try again</a>";
            }

        } else {
            echo "User not found.<br><a href='tenant_login.php'>Try again</a>";
        }

    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
