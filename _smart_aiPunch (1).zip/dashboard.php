<?php
session_start();
require 'db.php';
if (!isset($_SESSION['platform_logged_in']) || $_SESSION['platform_logged_in'] !== true) {
  header("Location: login.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Platform Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .dashboard-card {
      min-height: 120px;
      transition: transform 0.2s ease;
    }
    .dashboard-card:hover {
      transform: translateY(-5px);
    }
    .search-bar {
      max-width: 400px;
    }
  </style>
</head>
<body class="bg-light">
  <div class="container my-5">
    <h2 class="mb-4">🌐 Platform Admin Dashboard</h2>

    <!-- 🔍 Tenant Search -->
    <form class="mb-4">
      <input type="text" class="form-control search-bar" placeholder="Search tenants by name or subdomain...">
    </form>

    <div class="row g-4">
      <div class="col-md-4">
        <a href="enroll_tenant.php" class="btn btn-primary w-100 py-3 dashboard-card">➕ Enroll New Tenant</a>
      </div>
      <div class="col-md-4">
        <a href="manage_tenant_logins.php" class="btn btn-outline-primary w-100 py-3 dashboard-card">🧩 Manage Tenant Logins</a>
      </div>
      <div class="col-md-4">
        <a href="change_password.php" class="btn btn-outline-warning w-100 py-3 dashboard-card">🔐 Reset Tenant Admin Password</a>
      </div>
      <div class="col-md-4">
        <a href="logout.php" class="btn btn-danger w-100 py-3 dashboard-card">🚪 Logout</a>
      </div>
    </div>
  </div>

  <?php include 'footer.php'; ?>
</body>
</html>
