<?php
require 'db.php';
header("Content-Type: application/json");

$input = json_decode(file_get_contents("php://input"), true);

$employee_id   = $input['employee_id'] ?? null;
$lat           = $input['lat'];
$lng           = $input['lng'];
$pincode       = $input['pincode'] ?? '';
$area          = $input['area'] ?? '';
$city          = $input['city'] ?? '';
$selfie_data   = $input['photo']; // base64 image
$device_id     = $input['device_id'] ?? '';
$punch_source  = $input['punch_source'] ?? 'mobile'; // or 'kiosk', 'web'
$punch_type    = $input['punch_type'] ?? 'in'; // default to 'in'

if (!$employee_id || !$lat || !$lng || !$selfie_data) {
  http_response_code(400);
  exit("❌ Missing required fields.");
}

// 📷 Save selfie to file system
$img_folder = 'selfies/';
$img_name   = uniqid("emp{$employee_id}_") . ".jpg";
$img_path   = $img_folder . $img_name;
file_put_contents($img_path, base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $selfie_data)));

// 🧭 Compose location string
$location_desc = "$area, $city";

// 🎯 GPS coords
$gps_coords = "$lat,$lng";

// ⏱ Insert into DB
$stmt = $pdo->prepare("
  INSERT INTO attendance_logs 
  (employee_id, punch_type, punch_time, selfie_url, gps_coords, location_desc, latitude, longitude, pin_code, device_id, punch_source)
  VALUES (?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?)
");

$ok = $stmt->execute([
  $employee_id,
  $punch_type,
  $img_path,
  $gps_coords,
  $location_desc,
  $lat,
  $lng,
  $pincode,
  $device_id,
  $punch_source
]);

echo $ok ? "✅ Attendance recorded." : "❌ Failed to log attendance.";
