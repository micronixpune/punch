<?php
session_start();
require 'db.php';

if (!isset($_SESSION['platform_logged_in']) || $_SESSION['platform_logged_in'] !== true) {
  header("Location: login.php");
  exit;
}

// Stats
$totalTenants = $pdo->query("SELECT COUNT(*) FROM tenants")->fetchColumn();
$totalTenantUsers = $pdo->query("SELECT COUNT(*) FROM tenant_users")->fetchColumn();
$pendingUsers = $pdo->query("SELECT COUNT(*) FROM tenant_users WHERE password_hash IS NULL")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Platform Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/kiosk.css">
  <link rel="stylesheet" href="assets/css/dark-mode.css">


  <style>
    .card-hover { transition: transform 0.2s ease; cursor: pointer; }
    .card-hover:hover { transform: translateY(-6px); }
    .stat-box { border-left: 5px solid #0d6efd; background-color: #f8f9fa; }
    .search-bar { max-width: 420px; }
  </style>
</head>
<body class="bg-light">

<div class="container my-5">
  <h2 class="mb-4">🌐 Platform Admin Dashboard</h2>

  <!-- 📊 Stats -->
  <div class="row mb-4">
    <div class="col-md-4">
      <div class="p-3 shadow-sm stat-box">
        <h6 class="text-primary mb-1">🏢 Total Tenants</h6>
        <h3><?= $totalTenants ?></h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-3 shadow-sm stat-box" style="border-left-color: #198754;">
        <h6 class="text-success mb-1">👥 Tenant Users</h6>
        <h3><?= $totalTenantUsers ?></h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-3 shadow-sm stat-box" style="border-left-color: #ffc107;">
        <h6 class="text-warning mb-1">⏳ Pending Admin Setups</h6>
        <h3><?= $pendingUsers ?></h3>
      </div>
    </div>
  </div>

  <!-- 🔍 Tenant Search -->
  <form method="get" action="tenant_dashboard_redirect.php" class="mb-4">
    <input type="text" name="search" class="form-control search-bar" placeholder="Search tenants by subdomain or name...">
  </form>

  <!-- 🚀 Actions -->
  <div class="row g-4">
    <div class="col-md-4">
      <a href="enroll_tenant.php" class="text-decoration-none">
        <div class="card card-hover shadow-sm p-3 text-center border-primary">
          <h5>➕ Enroll New Tenant</h5>
        </div>
      </a>
    </div>
    <div class="col-md-4">
      <a href="manage_tenant_logins.php" class="text-decoration-none">
        <div class="card card-hover shadow-sm p-3 text-center border-info">
          <h5>🧩 Manage Tenant Logins</h5>
        </div>
      </a>
    </div>
    <div class="col-md-4">
      <a href="change_password.php" class="text-decoration-none">
        <div class="card card-hover shadow-sm p-3 text-center border-warning">
          <h5>🔐 Reset Tenant Admin Password</h5>
        </div>
      </a>
    </div>
    <div class="col-md-4">
      <a href="logout.php" class="text-decoration-none">
        <div class="card card-hover shadow-sm p-3 text-center border-danger">
          <h5>🚪 Logout</h5>
        </div>
      </a>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
</body>
</html>


