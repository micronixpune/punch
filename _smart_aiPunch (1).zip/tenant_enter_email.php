<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'];

    $stmt = $pdo->prepare("SELECT * FROM tenant_users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if (empty($user['password_hash'])) {
            // No password set → redirect to password setup
            header("Location: set_password.php?email=" . urlencode($email));
            exit();
        } else {
            // Password exists → redirect to login screen
            header("Location: tenant_password_login.php?email=" . urlencode($email));
            exit();
        }
    } else {
        echo "❌ Email not found.<br><a href='tenant_enter_email.php'>Try again</a>";
    }

    exit();
}
?>

<!DOCTYPE html>
<html>
<head><title>Tenant Login – Step 1</title></head>
<body>
  <h2>Welcome to Smart Attendance</h2>
  <form method="POST">
    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>
    <button type="submit">Next</button>
  </form>
</body>
</html>
