<?php
session_start();
require 'db.php';

// 🔄 Auto-redirect if already logged in
if (isset($_SESSION['platform_logged_in']) && $_SESSION['platform_logged_in'] === true) {
  header("Location: dashboard.php");
  exit;
}

if (isset($_SESSION['tenant_logged_in']) && $_SESSION['tenant_logged_in'] === true) {
  if ($_SESSION['tenant_role'] === 'admin') {
    header("Location: dashboard_admin.php");
    exit;
  } elseif ($_SESSION['tenant_role'] === 'employee') {
    header("Location: dashboard_employee.php");
    exit;
  }
}


$role = '';
$error = '';
$isTenantLogin = isset($_GET['tenant']);
$tenant_slug = $_GET['tenant'] ?? '';
$tenant = null;

// Auto-login for tenant via cookie
if ($isTenantLogin && isset($_COOKIE['user_token'])) {
  $token = $_COOKIE['user_token'];
  $stmt = $pdo->prepare("SELECT * FROM employees WHERE login_token = ?");
  $stmt->execute([$token]);
  $user = $stmt->fetch();

  if ($user) {
    $_SESSION['tenant_logged_in'] = true;
    $_SESSION['tenant_user_id'] = $user['id'];
    $_SESSION['tenant_id'] = $user['tenant_id'];
    $_SESSION['tenant_role'] = $user['role'];
    header("Location: " . ($user['role'] === 'admin' ? 'dashboard_admin.php' : 'dashboard_employee.php'));
    exit;
  }
}

// Load tenant info if tenant login
if ($isTenantLogin) {
  $stmt = $pdo->prepare("SELECT * FROM tenants WHERE subdomain_url = ?");
  $stmt->execute([$tenant_slug]);
  $tenant = $stmt->fetch();

  if (!$tenant) {
    die("❌ Tenant not found.");
  }
}

// Platform Admin Login
// Platform Admin Login (tenant_id IS NULL + role = admin)
if (!$isTenantLogin && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'] ?? '';
  $password = $_POST['password'] ?? '';

  $stmt = $pdo->prepare("
    SELECT * FROM employees 
    WHERE employee_code = ? 
      AND role = 'admin' 
      AND tenant_id IS NULL
  ");
  $stmt->execute([$username]);
  $user = $stmt->fetch();
  
  
  if ($user && password_verify($password, $user['password'])) {
    $_SESSION['platform_logged_in'] = true;
    $_SESSION['platform_user_id'] = $user['id'];
    header("Location: dashboard.php");
    exit;
  } else {
    $error = "Invalid platform login credentials.";
  }
}


// Tenant Login Logic
if ($isTenantLogin && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $employee_code = $_POST['employee_code'] ?? '';
  $password = $_POST['password'] ?? null;
  $dob = $_POST['dob'] ?? null;
  $role = $_POST['role'] ?? '';

  $stmt = $pdo->prepare("SELECT * FROM employees WHERE tenant_id = ? AND employee_code = ? AND role = ?");
  $stmt->execute([$tenant['id'], $employee_code, $role]);
  $user = $stmt->fetch();

  if ($user) {
    $valid = false;


    if ($role === 'admin' && password_verify($password, $user['password_hash'])) {
      $valid = true;
    } elseif ($role === 'employee' && $dob === $user['dob']) {
      $valid = true;
    }

    if ($valid) {
      $_SESSION['tenant_logged_in'] = true;
      $_SESSION['tenant_user_id'] = $user['id'];
      $_SESSION['tenant_id'] = $tenant['id'];
      $_SESSION['tenant_role'] = $role;

      $token = bin2hex(random_bytes(32));
      setcookie('user_token', $token, time() + (30 * 24 * 60 * 60), "/");

      $stmt = $pdo->prepare("UPDATE employees SET login_token = ? WHERE id = ?");
      $stmt->execute([$token, $user['id']]);

      header("Location: " . ($role === 'admin' ? 'dashboard_admin.php' : 'dashboard_employee.php'));
      exit;
    } else {
      $error = "Invalid credentials.";
    }
  } else {
    $error = "User not found.";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title><?= $isTenantLogin && isset($tenant['name']) ? htmlspecialchars($tenant['name']) . ' – Login' : 'Micronix TimePunch Platform Login' ?></title>
  <link rel="manifest" href="manifest.json" />
  
  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/kiosk.css">
  <link rel="stylesheet" href="assets/css/dark-mode.css">

  <meta name="theme-color" content="#0d6efd" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
  <div class="container mt-5">
    <div class="text-center mb-4">
      <?php if ($isTenantLogin && !empty($tenant['logo_url'])): ?>
        <img src="<?= $tenant['logo_url'] ?>" height="80" alt="Tenant Logo" /><br />
      <?php endif; ?>
      <h3 class="mt-2"><?= $isTenantLogin ? htmlspecialchars($tenant['name']) . ' Portal' : 'Micronix TimePunch Platform' ?></h3>
      <p class="text-muted"><?= $isTenantLogin ? 'Login as Admin or Employee' : 'Platform Admin Login' ?></p>
      <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php endif; ?>
    </div>

    <?php if ($isTenantLogin): ?>
      <div class="row">
        <div class="col-md-6">
          <h5>Tenant Admin Login</h5>
          <form method="POST">
            <input type="hidden" name="role" value="admin">
            <div class="mb-3">
              <label class="form-label">Employee Code</label>
              <input type="text" name="employee_code" class="form-control" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Login as Admin</button>
          </form>
        </div>
        <div class="col-md-6">
          <h5>Employee Login</h5>
          <form method="POST">
            <input type="hidden" name="role" value="employee">
            <div class="mb-3">
              <label class="form-label">Employee Code</label>
              <input type="text" name="employee_code" class="form-control" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Date of Birth</label>
              <input type="date" name="dob" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Login as Employee</button>
          </form>
        </div>
      </div>
    <?php else: ?>
      <div class="row justify-content-center">
        <div class="col-md-5">
          <form method="POST" class="border p-4 bg-light rounded shadow-sm">
            <div class="mb-3">
              <label class="form-label">Platform Username</label>
              <input type="text" name="username" class="form-control" required />
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" required />
            </div>
            <button type="submit" class="btn btn-primary w-100">Login to Dashboard</button>
          </form>
          <div class="text-center mt-3">
            <a href="request_access.php" class="btn btn-outline-secondary">Request Access for Your Organization</a>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <?php include 'footer.php'; ?>
</body>
</html>
