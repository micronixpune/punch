<?php
session_start();
if (isset($_SESSION['tenant_logged_in'])) {
    header("Location: tenant_dashboard.php");
    exit();
}

if (!isset($_GET['email'])) {
    header("Location: tenant_enter_email.php");
    exit();
}

$email = $_GET['email'];
?>

<!DOCTYPE html>
<html>
<head><title>Enter Password – Smart Attendance</title></head>
<body>
  <h2>Welcome back, <?= htmlspecialchars($email) ?></h2>
  <form action="tenant_login_handler.php" method="POST">
    <input type="hidden" name="email" value="<?= htmlspecialchars($email) ?>">

    <label>Password:</label><br>
    <input type="password" name="password" required><br><br>

    <button type="submit">Login</button>
  </form>

  <p><a href="tenant_enter_email.php">Back</a></p>
</body>
</html>
