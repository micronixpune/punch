<?php
require 'db.php';
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $org_name = $_POST['org_name'];
  $slug = strtolower(preg_replace('/[^a-z0-9]+/', '-', $org_name));
  $registered_address = $_POST['registered_address'];
  $tax_info = $_POST['tax_info'];
  $phone = $_POST['phone_number'];
  $email = $_POST['email_id'];
  $admin_name = $_POST['admin_name'];
  $admin_email = $_POST['admin_email'];
  $superuser_name = $_POST['superuser_name'];
  $superuser_email = $_POST['superuser_email'];

  // Handle logo upload
  $logo_url = '';
  if (isset($_FILES['logo']) && $_FILES['logo']['error'] === 0) {
    $fname = uniqid() . '_' . basename($_FILES['logo']['name']);
    $target = "uploads/tenant_logos/" . $fname;
    if (move_uploaded_file($_FILES['logo']['tmp_name'], $target)) {
      $logo_url = $target;
    }
  }

  try {
    // Insert tenant
    $stmt = $pdo->prepare("INSERT INTO tenants (
      org_name, subdomain_url, logo_url,
      registered_address, tax_info, phone_number, email_id,
      admin_name, admin_email, superuser_name, superuser_email
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->execute([
      $org_name, $slug, $logo_url,
      $registered_address, $tax_info, $phone, $email,
      $admin_name, $admin_email, $superuser_name, $superuser_email
    ]);

    $tenant_id = $pdo->lastInsertId();
    $login_code = 'TNT' . str_pad($tenant_id, 3, '0', STR_PAD_LEFT);
    $starter_pass = substr(str_shuffle('Abcd1234!@#$'), 0, 8);
    $hashed = password_hash($starter_pass, PASSWORD_DEFAULT);

    // Insert admin user
    $admin_first = strtok($admin_name, ' ');
    $admin_last = trim(str_replace($admin_first, '', $admin_name));

    $stmt = $pdo->prepare("INSERT INTO employees (
      tenant_id, login_code, first_name, last_name, email_id, role, password
    ) VALUES (?, ?, ?, ?, ?, 'admin', ?)");

    $stmt->execute([$tenant_id, $login_code, $admin_first, $admin_last, $admin_email, $hashed]);
    $login_link = "https://micronix.co.in/smart_aiPunch/login.php?tenant=" . urlencode($slug);


    $success = "✅ Tenant <strong>$org_name</strong> enrolled successfully!<br>
  <strong>Admin Login Code:</strong> <code>$login_code</code><br>
  <strong>Temporary Password:</strong> <code>$starter_pass</code><br>
  <strong>Login URL:</strong> <a href='$login_link' target='_blank'>$login_link</a>";


  } catch (Exception $e) {
    $error = $e->getMessage();
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Enroll New Tenant</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2 class="mb-4">Enroll New Tenant</h2>

  <?php if ($success): ?>
    <div class="alert alert-success"><?= $success ?></div>
  <?php elseif ($error): ?>
    <div class="alert alert-danger">❌ <?= $error ?></div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data">
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Organization Name</label>
        <input type="text" name="org_name" class="form-control" required>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Logo Upload</label>
        <input type="file" name="logo" accept="image/*" class="form-control">
      </div>
    </div>

    <div class="mb-3">
      <label class="form-label">Registered Address</label>
      <textarea name="registered_address" class="form-control" rows="2" required></textarea>
    </div>

    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Tax Information</label>
        <input type="text" name="tax_info" class="form-control">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Phone Number</label>
        <input type="tel" name="phone_number" class="form-control">
      </div>
    </div>

    <div class="mb-3">
      <label class="form-label">Official Email ID</label>
      <input type="email" name="email_id" class="form-control">
    </div>

    <hr>
    <h5>Tenant Admin Contact</h5>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Admin Name</label>
        <input type="text" name="admin_name" class="form-control">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Admin Email</label>
        <input type="email" name="admin_email" class="form-control">
      </div>
    </div>

    <h5>Super User Contact</h5>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Super User Name</label>
        <input type="text" name="superuser_name" class="form-control">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Super User Email</label>
        <input type="email" name="superuser_email" class="form-control">
      </div>
    </div>

    <div class="text-end">
      <button type="submit" class="btn btn-primary">Enroll Tenant</button>
    </div>
  </form>

  <footer class="text-center text-muted mt-5 small">
    Designed & Developed by <strong>Micronix Solutions, Pune</strong><br>
    Contact: +91 9960679505 | Email: <a href="mailto:info@micronix.co.in">info@micronix.co.in</a>
  </footer>
</div>
</body>
</html>
