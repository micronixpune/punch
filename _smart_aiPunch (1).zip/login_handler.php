<?php
session_start();

// Hardcoded App Creator credentials
$admin_email = "admin@micronix.co.in";
$admin_password = "Admin1234!";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $input_email = $_POST['email'] ?? '';
    $input_password = $_POST['password'] ?? '';

    if ($input_email === $admin_email && $input_password === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: dashboard.php");
        exit();
    } else {
        echo "❌ Invalid credentials.<br><a href='login.php'>Try again</a>";
    }
} else {
    echo "Invalid access method.";
}
?>
