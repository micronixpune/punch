<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require '../db.php'; // Adjust if db connection is elsewhere
header('Content-Type: application/json');

// Decode JSON input
$data = json_decode(file_get_contents("php://input"), true);

// Basic input validation
if (!isset($data['employee_id'], $data['lat'], $data['lon'])) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
  exit;
}

$employee_id  = $data['employee_id'];
$tenant_id    = $data['tenant_id'] ?? null;
$punch_type   = $data['punch_type'] ?? 'in';
$punch_time   = date('Y-m-d H:i:s');
$lat          = $data['lat'];
$lon          = $data['lon'];
$device_id    = $data['device_id'] ?? 'unknown';
$punch_source = $data['source'] ?? 'mobile';
$selfie_url   = $data['selfie_url'] ?? null;
$address      = $data['address'] ?? '';
$pincode      = $data['pincode'] ?? '';
$gps_string   = $lat . ',' . $lon;

// Fetch employee details
$stmt = $pdo->prepare("SELECT e.*, t.office_lat, t.office_lon FROM employees e
  JOIN tenants t ON e.tenant_id = t.id WHERE e.id = ?");
$stmt->execute([$employee_id]);
$user = $stmt->fetch();

if (!$user) {
  echo json_encode(['status' => 'error', 'message' => 'Employee not found']);
  exit;
}

// Geo-fence logic for stationed employees
if ($user['working_type'] === 'stationed') {
  $dist = haversine($lat, $lon, $user['office_lat'], $user['office_lon']);
  if ($dist > 0.1) { // radius in km (0.1 km = 100m)
    echo json_encode(['status' => 'error', 'message' => 'Outside allowed location']);
    exit;
  }
}

// Insert into attendance_logs
$stmt = $pdo->prepare("INSERT INTO attendance_logs (
  employee_id, punch_type, punch_time,
  latitude, longitude, gps_coords,
  location_desc, pin_code,
  device_id, punch_source, selfie_url
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->execute([
  $employee_id, $punch_type, $punch_time,
  $lat, $lon, $gps_string,
  $address, $pincode,
  $device_id, $punch_source, $selfie_url
]);

echo json_encode(['status' => 'success', 'timestamp' => $punch_time]);

// Optional: You can log this to a punch activity log file too

// Haversine formula (km)
function haversine($lat1, $lon1, $lat2, $lon2) {
  $earthRadius = 6371;
  $dLat = deg2rad($lat2 - $lat1);
  $dLon = deg2rad($lon2 - $lon1);
  $a = sin($dLat/2) * sin($dLat/2) +
       cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
       sin($dLon/2) * sin($dLon/2);
  $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
  return $earthRadius * $c;
}
?>
