<?php
header("Location: tenant_enter_email.php");
exit();
?>
