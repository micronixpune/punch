// dark-mode.js
const toggle = document.getElementById('darkToggle');
const root = document.documentElement;

function applyTheme(isDark) {
  root.classList.toggle('dark-mode', isDark);
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
}

toggle.addEventListener('click', () => {
  const isDark = root.classList.toggle('dark-mode');
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  toggle.innerText = isDark ? '☀️' : '🌙';
});

// Load on startup
document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('theme');
  if (saved === 'dark') {
    root.classList.add('dark-mode');
    toggle.innerText = '☀️';
  } else {
    toggle.innerText = '🌙';
  }
});
