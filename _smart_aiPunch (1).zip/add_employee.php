<?php
session_start();
require 'db.php';

if (!isset($_SESSION['tenant_logged_in'])) {
    header("Location: tenant_enter_email.php");
    exit();
}

$tenant_id = $_SESSION['tenant_id'];
$created_by = $_SESSION['tenant_user_id'];
$photo_url = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Handle photo upload
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
        $filename = uniqid() . '_' . basename($_FILES['photo']['name']);
        $target = "uploads/" . $filename;
        move_uploaded_file($_FILES['photo']['tmp_name'], $target);
        $photo_url = $target;
    }

    $weekly_off = isset($_POST['weekly_off_day']) ? implode(', ', $_POST['weekly_off_day']) : '';

    try {
        $stmt = $pdo->prepare("INSERT INTO employees (
            tenant_id, employee_code, title, first_name, middle_name, last_name, dob, gender,
            aadhar_number, pan_number, photo_url, phone_number,
            current_address, permanent_address, designation, department, reporting_manager,
            is_flexi_hours, office_start, office_end,
            basic_salary, hra, allowance1, allowance2, allowance3,
            advance_paid1, advance_paid2, emp_pf, employer_pf, prof_tax,
            advance1, advance2, deduction1, deduction2,
            allowed_leaves, leaves_from, weekly_off_day, working_type,
            created_by
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )");

        $stmt->execute([
            $tenant_id,
            $_POST['employee_code'],
            $_POST['title'],
            $_POST['first_name'],
            $_POST['middle_name'],
            $_POST['last_name'],
            $_POST['dob'],
            $_POST['gender'],
            $_POST['aadhar_number'],
            $_POST['pan_number'],
            $photo_url,
            $_POST['phone_number'],
            $_POST['current_address'],
            $_POST['permanent_address'],
            $_POST['designation'],
            $_POST['department'],
            $_POST['reporting_manager'],
            isset($_POST['is_flexi_hours']) ? 1 : 0,
            $_POST['office_start'],
            $_POST['office_end'],
            $_POST['basic_salary'],
            $_POST['hra'],
            $_POST['allowance1'],
            $_POST['allowance2'],
            $_POST['allowance3'],
            $_POST['advance_paid1'],
            $_POST['advance_paid2'],
            $_POST['emp_pf'],
            $_POST['employer_pf'],
            $_POST['prof_tax'],
            $_POST['advance1'],
            $_POST['advance2'],
            $_POST['deduction1'],
            $_POST['deduction2'],
            $_POST['allowed_leaves'],
            $_POST['leaves_from'],
            $weekly_off,
            $_POST['working_type'],
            $created_by
        ]);

        echo "✅ Employee added successfully!<br><a href='add_employee.php'>Add Another</a> | <a href='tenant_dashboard.php'>Dashboard</a>";
        exit();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <div class="container mt-4">
  <h2 class="mb-4">Add New Employee</h2>
  <form method="POST" enctype="multipart/form-data">

    <!-- PERSONAL INFO -->
    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">Employee Code</label>
        <input type="text" class="form-control" name="employee_code" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Title</label>
        <select class="form-select" name="title" required>
          <option value="">--Select--</option>
          <option>Mr</option><option>Mrs</option><option>Ms</option>
        </select>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Gender</label>
        <select class="form-select" name="gender" required>
          <option value="">--Select--</option>
          <option value="M">Male</option><option value="F">Female</option>
        </select>
      </div>
    </div>

    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">First Name</label>
        <input type="text" class="form-control" name="first_name" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Middle Name</label>
        <input type="text" class="form-control" name="middle_name">
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Last Name</label>
        <input type="text" class="form-control" name="last_name" required>
      </div>
    </div>

    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">Date of Birth</label>
        <input type="date" class="form-control" name="dob" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Aadhar Number</label>
        <input type="text" class="form-control" name="aadhar_number" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">PAN Number</label>
        <input type="text" class="form-control" name="pan_number" required>
      </div>
    </div>

    <!-- CONTACT INFO -->
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Phone Number</label>
        <input type="text" class="form-control" name="phone_number" required>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Upload Photo</label>
        <input type="file" class="form-control" name="photo" accept="image/*" capture="environment" required>
      </div>
    </div>

    <!-- ADDRESSES -->
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Current Address</label>
        <textarea class="form-control" name="current_address" rows="2" required></textarea>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Permanent Address</label>
        <textarea class="form-control" name="permanent_address" rows="2" required></textarea>
      </div>
    </div>

    <!-- JOB DETAILS -->
    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">Designation</label>
        <input type="text" class="form-control" name="designation" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Department</label>
        <input type="text" class="form-control" name="department" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Reporting Manager</label>
        <input type="text" class="form-control" name="reporting_manager" required>
      </div>
    </div>

    <!-- ATTENDANCE -->
    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">Office Start Time</label>
        <input type="time" class="form-control" name="office_start" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Office End Time</label>
        <input type="time" class="form-control" name="office_end" required>
      </div>
      <div class="col-md-4 mb-3 d-flex align-items-center">
        <div class="form-check mt-3">
          <input class="form-check-input" type="checkbox" name="is_flexi_hours" id="flexi">
          <label class="form-check-label" for="flexi">Flexi Hours?</label>
        </div>
      </div>
    </div>

    <!-- WEEKLY OFFS -->
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Weekly Off Days (Max 2)</label>
        <div class="d-flex flex-wrap gap-2">
          <?php
            $days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
            foreach($days as $d) {
              echo "<div class='form-check'><input class='form-check-input' type='checkbox' name='weekly_off_day[]' value='$d' id='$d'>";
              echo "<label class='form-check-label' for='$d'>$d</label></div>";
            }
          ?>
        </div>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Working Type</label>
        <select class="form-select" name="working_type" required>
          <option value="">--Select--</option>
          <option value="stationed">Stationed</option>
          <option value="roaming">Roaming</option>
        </select>
      </div>
    </div>

    <!-- SALARY -->
    <div class="row">
      <?php
        $salaryFields = [
          'basic_salary','hra','allowance1','allowance2','allowance3',
          'advance_paid1','advance_paid2','emp_pf','employer_pf','prof_tax',
          'advance1','advance2','deduction1','deduction2'
        ];
        foreach ($salaryFields as $sf) {
          $label = ucwords(str_replace('_', ' ', $sf));
          echo "<div class='col-md-4 mb-3'><label class='form-label'>$label</label>";
          echo "<input type='number' step='0.01' class='form-control' name='$sf' required></div>";
        }
      ?>
    </div>

    <!-- LEAVE POLICY -->
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Allowed Leaves</label>
        <input type="number" class="form-control" name="allowed_leaves" required>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Leaves From</label>
        <input type="date" class="form-control" name="leaves_from" required>
      </div>
    </div>

    <!-- BUTTONS -->
    <div class="row">
      <div class="col-12 text-end mt-3">
        <button type="submit" class="btn btn-primary">Add Employee</button>
        <a href="tenant_dashboard.php" class="btn btn-secondary ms-2">Cancel</a>
      </div>
    </div>
  </form>
</div>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</style>

  