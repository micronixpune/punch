<?php
session_start();
require 'db.php';
if (!isset($_SESSION['tenant_logged_in']) || $_SESSION['tenant_role'] !== 'admin') {
  header("Location: login.php");
  exit;
}
$tenant_id = $_SESSION['tenant_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Tenant Admin Dashboard – TimePunch</title>
  <link rel="manifest" href="manifest.json" />
  <meta name="theme-color" content="#0d6efd" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
  <div class="container py-5">
    <h2 class="mb-4">👋 Welcome, Admin</h2>
    <div class="alert alert-success">Manage your employees, monitor attendance, and update your portal settings.</div>
    <ul class="list-group">
      <li class="list-group-item"><a href="employees.php?tenant=<?= $tenant_id ?>">Manage Employees</a></li>
      <li class="list-group-item"><a href="attendance.php?tenant=<?= $tenant_id ?>">View Attendance Logs</a></li>
      <li class="list-group-item"><a href="settings.php?tenant=<?= $tenant_id ?>">Tenant Settings</a></li>
    </ul>
    <div class="text-end mt-4">
      <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>
  </div>
  <?php include 'footer.php'; ?>
</body>
</html>
