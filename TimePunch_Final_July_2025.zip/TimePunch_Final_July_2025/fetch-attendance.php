<?php
header('Content-Type: application/json');
require '../db.php';

session_start();
if (!isset($_SESSION['tenant_logged_in'])) {
  echo json_encode(['status' => 'unauthorized']);
  exit;
}

$user_id = $_SESSION['tenant_user_id'];
$role = $_SESSION['tenant_role'];

if ($role === 'employee') {
  $stmt = $pdo->prepare("SELECT * FROM attendance_logs WHERE employee_id = ? ORDER BY timestamp DESC");
  $stmt->execute([$user_id]);
} else {
  $tenant_id = $_SESSION['tenant_id'];
  $stmt = $pdo->prepare("SELECT * FROM attendance_logs WHERE tenant_id = ? ORDER BY timestamp DESC");
  $stmt->execute([$tenant_id]);
}

$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode(['status' => 'ok', 'logs' => $logs]);
?>
