<?php
session_start();
require 'db.php';
if (!isset($_SESSION['tenant_logged_in']) || $_SESSION['tenant_role'] !== 'employee') {
  header("Location: login.php");
  exit;
}
$employee_id = $_SESSION['tenant_user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>My Dashboard – TimePunch</title>
  <link rel="manifest" href="manifest.json" />
  <meta name="theme-color" content="#0d6efd" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
  <div class="container py-5">
    <h2 class="mb-4">👋 Welcome, Employee</h2>
    <div class="alert alert-light">Here’s your recent activity and quick punch access.</div>
    <ul class="list-group">
      <li class="list-group-item"><a href="api/punch-in.php">Record My Attendance</a></li>
      <li class="list-group-item"><a href="my_attendance.php">My Attendance Logs</a></li>
    </ul>
    <div class="text-end mt-4">
      <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>
  </div>
  <?php include 'footer.php'; ?>
</body>
</html>
