<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $org = $_POST['org'];
  $address = $_POST['address'];
  $website = $_POST['website'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $employees = $_POST['employees'];

  $to = "info@micronix.co.in";
  $subject = "New TimePunch Access Request";
  $message = "
Organization: $org
Address: $address
Website: $website
Email: $email
Phone: $phone
Employees: $employees
";
  $headers = "From: noreply@micronix.co.in";

  if (mail($to, $subject, $message, $headers)) {
    $success = true;
  } else {
    $error = "There was a problem sending your request. Please try again.";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Request Access - TimePunch</title>
  <link rel="manifest" href="manifest.json" />
  <meta name="theme-color" content="#0d6efd" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <div class="container py-5">
    <h2 class="text-center mb-4">Request Access for Your Organization</h2>
    <div class="row justify-content-center">
      <div class="col-md-6">
        <?php if (isset($success)): ?>
          <div class="alert alert-success">✅ Thank you! We’ll be in touch shortly.</div>
        <?php elseif (isset($error)): ?>
          <div class="alert alert-danger">❌ <?= $error ?></div>
        <?php endif; ?>
        <form method="POST" class="border p-4 bg-white rounded shadow-sm">
          <div class="mb-3">
            <label class="form-label">Organization Name *</label>
            <input type="text" name="org" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Organization Address *</label>
            <textarea name="address" class="form-control" rows="2" required></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Website (optional)</label>
            <input type="text" name="website" class="form-control" />
          </div>
          <div class="mb-3">
            <label class="form-label">Email ID *</label>
            <input type="email" name="email" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Mobile Number *</label>
            <input type="tel" name="phone" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Number of Employees *</label>
            <input type="number" name="employees" class="form-control" required />
          </div>
          <button type="submit" class="btn btn-success w-100">Submit Request</button>
        </form>
      </div>
    </div>
  </div>
  <?php include 'footer.php'; ?>
</body>
</html>
