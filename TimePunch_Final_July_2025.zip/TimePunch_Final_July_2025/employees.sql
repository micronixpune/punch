CREATE TABLE employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT,
  employee_code VARCHAR(50) NOT NULL,
  name VARCHAR(100),
  phone_number VARCHAR(20),
  dob DATE,
  role ENUM('employee', 'admin', 'platform') NOT NULL,
  login_token VARCHAR(64),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);
