<?php
header('Content-Type: application/json');
require '../db.php';

session_start();
if (!isset($_SESSION['tenant_logged_in']) || $_SESSION['tenant_role'] !== 'employee') {
  echo json_encode(['status' => 'unauthorized']);
  exit;
}

$employee_id = $_SESSION['tenant_user_id'];
$tenant_id = $_SESSION['tenant_id'];
$timestamp = date('Y-m-d H:i:s');

// Optional: Capture location from POST
$location = $_POST['location'] ?? 'Unknown';

$stmt = $pdo->prepare("INSERT INTO attendance_logs (employee_id, tenant_id, timestamp, location) VALUES (?, ?, ?, ?)");
$stmt->execute([$employee_id, $tenant_id, $timestamp, $location]);

echo json_encode(['status' => 'success', 'timestamp' => $timestamp]);
?>
