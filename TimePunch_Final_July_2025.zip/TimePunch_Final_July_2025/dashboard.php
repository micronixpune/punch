<?php
session_start();
require 'db.php';

if (!isset($_SESSION['platform_logged_in'])) {
  header("Location: login.php");
  exit;
}

$platform_user_id = $_SESSION['platform_user_id'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Platform Dashboard – TimePunch</title>
  <meta name="theme-color" content="#0d6efd" />
  <link rel="manifest" href="manifest.json" />
  <link rel="stylesheet" href="css/style.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
  <div class="container py-5">
    <h2 class="mb-4">👋 Welcome, Platform Admin</h2>

    <div class="alert alert-primary">This is your central command center for managing tenants, onboarding new organizations, and tracking system-wide activity.</div>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="p-4 bg-white rounded border shadow-sm h-100">
          <h5 class="mb-2">📦 Manage Tenants</h5>
          <p>Add, edit, or remove tenant organizations and assign subdomain URLs.</p>
          <a href="tenants.php" class="btn btn-outline-primary btn-sm">View Tenants</a>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-4 bg-white rounded border shadow-sm h-100">
          <h5 class="mb-2">🧑‍💼 Platform Users</h5>
          <p>View and manage employees tagged with <code>role = 'platform'</code>.</p>
          <a href="users.php?role=platform" class="btn btn-outline-secondary btn-sm">View Users</a>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-4 bg-white rounded border shadow-sm h-100">
          <h5 class="mb-2">📨 Access Requests</h5>
          <p>Manually review email requests received from <code>request_access.php</code>.</p>
          <a href="https://micronix.co.in/mailbox" class="btn btn-outline-success btn-sm">Open Inbox</a>
        </div>
      </div>
    </div>

    <div class="text-end mt-5">
      <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
  </div>

  <?php include 'footer.php'; ?>
</body>
</html>
